
DAY 01 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial1
        |-- PythonNotes
            |-- PythonStudyNotes1.pdf

            |-- Python.02.DataTypes.pdf
            |-- Python.03.CollectionDataTypes.pdf

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial1
        |-- PythonCode
        |   `-- PythonExperiments1.py


DAY 02 : ASSIGNMENTS
________________________________________________________________


1. Reading Assignments

    |-- StudyMaterial2

        |-- PythonNotes
            |-- PythonStudyNotes2.pdf
            |-- Python.04.ControlStructuresAndFunctions.pdf

2.  Experiment And Revise Code Examples

    |-- StudyMaterial2

        |-- PythonCode
        |   |-- Discussions.py
        |   |-- Functions.py
        |   |-- Hello.py
        |   |-- PythonExperiments1.py
        |   |-- PythonExperiments2.py
        |   |-- ReadFiles.py
        |   `-- wordsList.txt


3.  Experiment And Reason Following Code Examples

    |-- StudyMaterial2

        |-- PracticePythonCode
        |   |-- Module01.PythonIntroduction
        |   |   |-- average1_ans.py
        |   |   |-- average2_ans.py
        |   |   |-- awfulpoetry1_ans.py
        |   |   |-- awfulpoetry2_ans.py
        |   |   |-- bigdigits.py
        |   |   |-- bigdigits_ans.py
        |   |   |-- echoargs.py
        |   |   |-- generate_grid.py
        |   |   |-- hello.py
        |   |   |-- sum1.py
        |   |   `-- sum2.py

        |   |-- Module02.DataTypes
        |   |   |-- csv2html.py
        |   |   |-- csv2html1_ans.py
        |   |   |-- csv2html2_ans.py
        |   |   |-- print_unicode.py
        |   |   |-- print_unicode_ans.py
        |   |   |-- print_unicode_uni.py
        |   |   |-- print_unicode_uni_ans.py
        |   |   |-- quadratic.py
        |   |   |-- quadratic_ans.py
        |   |   |-- quadratic_uni.py
        |   |   `-- quadratic_uni_ans.py
        
        |   |-- Module03.CollectionDataTypes
        |   |   |-- generate_usernames.py
        |   |   `-- statistics.py
        
        |   |-- Module04.ControlStructuresAndFunctions
        |       |-- digit_names.py
        |       `-- listkeeper.py


DAY 03 : ASSIGNMENTS
________________________________________________________________


