
infile = open("wordsList.txt")
lines = infile.read().split("\n")

wordsCount = 0
characterCount = 0

for line in lines:
    words = line.split()
    wordsCount = wordsCount + len(words)
    characterCount = characterCount + len(line)

print(" Words Count = {0}".format( wordsCount ))
print(" Character Count = {0}".format( characterCount ))

if __name__ == '__main__':
    print("Main Function")

