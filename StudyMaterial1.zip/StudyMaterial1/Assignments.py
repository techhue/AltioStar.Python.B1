
DAY 1 : ASSIGNMENTS
________________________________________________________________

1. Reading Assignments

    |-- StudyMaterial1
        |-- PythonNotes
            |-- PythonStudyNotes1.pdf
            |-- Python.02.DataTypes.pdf
            |-- Python.03.CollectionDataTypes.pdf

2.  Experiment And Revise Code Examples
    
    |-- StudyMaterial1
        |-- PythonCode
        |   `-- PythonExperiments1.py


DAY 2 : ASSIGNMENTS
________________________________________________________________


DAY 2 : ASSIGNMENTS
________________________________________________________________


