
# Higher Order Function
#		Function Returning A Function

# Decorator Function

#					Gift Is Passed Here
def simpleDecorator( functionPassed ):
	# Local Function
	
	def wrapper(): # Gift Wrapper
		print("Before functionPassed Called") # Decoration
		functionPassed() # Gift
		print("After functionPassed Called")  # Decoration

	return wrapper # Returning Wrapped/Decorated Gift

# Gift
def sayHello():
	print("Hello!")


print("sayHello Value Before Assignment")
print(sayHello)

#Decorated Gift	<- Decorating  Gift				
sayHello = simpleDecorator(sayHello)

print("sayHello Value After Assignment")
print(sayHello)

# sayHello Value Before Assignment
# <function sayHello at 0x7f475db2b150>
# sayHello Value After Assignment
# <function wrapper at 0x7f475db2b1d0>


sayHello()
# Before functionPassed Called
# Hello!
# After functionPassed Called

