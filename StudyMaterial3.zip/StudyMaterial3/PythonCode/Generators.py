
def numbersGiver():
	limit = 10
	numbers = []
	number = 1

	while number < limit:
		numbers.append(number)
		number = number + 1

	return numbers


# Generators Are Special Functions Which Yield Values On Demand
def numbersGenerator(start, end):
	limit = end
	numbers = []
	number = start

	while number < limit:
		numbers.append(number)
		yield number
		number = number + 1
				
#	return numbers


# Generators Are Special Functions Which Yield Values On Demand
def numbersInfiniteGenerator(start):
	numbers = []
	number = start

	while True:
		numbers.append(number)
		yield number
		number = number + 1


if __name__ == '__main__':

	print("\nCalling Function : numbersGiver")
	numbers = numbersGiver()
	print(numbers)


	print("\nCalling Function : numbersGenerator")
	numbersAgain = numbersGenerator(0, 10)
	print(numbersAgain)
	type(numbersAgain)

	for number in numbersAgain:
		print(number)


	print("\nCalling Function : numbersInfiniteGenerator")
	infiniteGenerator = numbersInfiniteGenerator(0)
	print(infiniteGenerator)
	type(infiniteGenerator)
