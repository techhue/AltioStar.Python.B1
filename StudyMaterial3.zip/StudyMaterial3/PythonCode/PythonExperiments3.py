
Python 2.7.18 (default, Mar  8 2021, 13:02:45) 
[GCC 9.3.0] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> import sys
>>> 
>>> dir(sys)
['__displayhook__', '__doc__', '__excepthook__', '__name__', '__package__', '__stderr__', '__stdin__', '__stdout__', '_clear_type_cache', '_current_frames', '_getframe', '_git', '_multiarch', 'api_version', 'argv', 'builtin_module_names', 'byteorder', 'call_tracing', 'callstats', 'copyright', 'displayhook', 'dont_write_bytecode', 'exc_clear', 'exc_info', 'exc_type', 'excepthook', 'exec_prefix', 'executable', 'exit', 'flags', 'float_info', 'float_repr_style', 'getcheckinterval', 'getdefaultencoding', 'getdlopenflags', 'getfilesystemencoding', 'getprofile', 'getrecursionlimit', 'getrefcount', 'getsizeof', 'gettrace', 'hexversion', 'long_info', 'maxint', 'maxsize', 'maxunicode', 'meta_path', 'modules', 'path', 'path_hooks', 'path_importer_cache', 'platform', 'prefix', 'ps1', 'ps2', 'py3kwarning', 'pydebug', 'setcheckinterval', 'setdlopenflags', 'setprofile', 'setrecursionlimit', 'settrace', 'stderr', 'stdin', 'stdout', 'subversion', 'version', 'version_info', 'warnoptions']
>>> 
>>> sys.platform
'linux2'
>>> 
>>> sys.stdout
<open file '<stdout>', mode 'w' at 0x7efd020e11e0>
>>> 
>>> sys.stdin
<open file '<stdin>', mode 'r' at 0x7efd020e1150>
>>> 
>>> sys.stderr
<open file '<stderr>', mode 'w' at 0x7efd020e1270>
>>> 
>>> sys.version
'2.7.18 (default, Mar  8 2021, 13:02:45) \n[GCC 9.3.0]'


#__________________________________________________________________

Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> openFile = open("wordsList1.txt")
>>> 
>>> lines = openFile.readlines()
>>> 
>>> lines
['Ding Dong\n', 'Ting Tong Ting Tong\n', 'Ping Pong Ting Tong Ding Dong\n', '\n', 'Zing    Zong     Zing\n', 'Ping  Mingo Vingoo\n', '\n', 'Mingo Vingoo\n', '\n']
>>> 
>>> for line in lines:
...     print(line)
... 
Ding Dong

Ting Tong Ting Tong

Ping Pong Ting Tong Ding Dong



Zing    Zong     Zing

Ping  Mingo Vingoo



Mingo Vingoo



>>> 
>>> for line in lines:
...     words = line.split()
... 
>>> words = []
>>> 
>>> for line in lines:
...     words = line.split()
... 
>>> words
[]
>>> 
>>> 
>>> for line in lines:
...     words = line.split()
...     print(words)
... 
['Ding', 'Dong']
['Ting', 'Tong', 'Ting', 'Tong']
['Ping', 'Pong', 'Ting', 'Tong', 'Ding', 'Dong']
[]
['Zing', 'Zong', 'Zing']
['Ping', 'Mingo', 'Vingoo']
[]
['Mingo', 'Vingoo']
[]
>>> 
>>> 
>>> someLine = "Something Great Happens \t And 
  File "<stdin>", line 1
    someLine = "Something Great Happens \t And 
                                              ^
SyntaxError: EOL while scanning string literal
>>> someLine = "Something Great Happens \t And \n Life is Awesome"
>>> 
>>> someLine.split()
['Something', 'Great', 'Happens', 'And', 'Life', 'is', 'Awesome']
>>> 
>>> 
>>> someLine.split("\n")
['Something Great Happens \t And ', ' Life is Awesome']
>>> 
>>> 
>>> someLine.split("\t")
['Something Great Happens ', ' And \n Life is Awesome']
>>> 
>>> someLine.split(" ")
['Something', 'Great', 'Happens', '\t', 'And', '\n', 'Life', 'is', 'Awesome']
>>> 
>>> 
>>> someLine.split()
['Something', 'Great', 'Happens', 'And', 'Life', 'is', 'Awesome']
>>> 
>>> 
>>> 
>>> wordsCount = {'Ding': 2, 'Zong': 1, 'Tong': 3, 'Mingo': 2, 'Ping': 2, 'Ting': 3, 'Zing': 2, 'Dong': 2, 'Pong': 1, 'Vingoo': 2}
>>> 
>>> wordsCount["Ding"]
2
>>> 
>>> wordsCount["Ching"]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 'Ching'
>>> 
>>> wordsCount["Ching"] = 10
>>> 
>>> wordsCount
{'Ding': 2, 'Zong': 1, 'Tong': 3, 'Mingo': 2, 'Ping': 2, 'Ting': 3, 'Zing': 2, 'Dong': 2, 'Pong': 1, 'Vingoo': 2, 'Ching': 10}
>>> 
>>> 
>>> wordsCount{"Bing"]
  File "<stdin>", line 1
    wordsCount{"Bing"]
              ^
SyntaxError: invalid syntax
>>> 
>>> wordsCount["Bing"]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
KeyError: 'Bing'
>>> 
>>> wordsCount.get("Bing")
>>> 
>>> wordsCount.get("Bing", 0)
0
>>> 
>>> sys.input
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'sys' is not defined
>>> 
>>> import sys
>>> sys.input
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: module 'sys' has no attribute 'input'
>>> 
>>> sys.stdin
<_io.TextIOWrapper name='<stdin>' mode='r' encoding='utf-8'>
>>> 
>>> sys.stdin.read()
Ding Dong
Ding Dong Ting Tong
'Ding Dong\nDing Dong Ting Tong\n'
>>> 
>>> 
>>> 
>>> 
>>> data = sys.stdin.read()
Ding Ding Ding Ting Ting Ting Ming Ming....
Ming Ming
Ting Ting
>>> 
>>> data
'Ding Ding Ding Ting Ting Ting Ming Ming....\nMing Ming\nTing Ting\n'
>>> 
>>> openFile = open("wordsList1.txt")
>>> openFile.readlines()
['Ding Dong\n', 'Ting Tong Ting Tong\n', 'Ping Pong Ting Tong Ding Dong\n', '\n', 'Zing    Zong     Zing\n', 'Ping  Mingo Vingoo\n', '\n', 'Mingo Vingoo\n', '\n']
>>> 
>>> 
>>> data
'Ding Ding Ding Ting Ting Ting Ming Ming....\nMing Ming\nTing Ting\n'
>>> print(data)
Ding Ding Ding Ting Ting Ting Ming Ming....
Ming Ming
Ting Ting

>>> sys.stdout.write(data)
Ding Ding Ding Ting Ting Ting Ming Ming....
Ming Ming
Ting Ting
64
>>> 
>>> someInput = input()
Ding 10 20
>>> 
>>> someInput
'Ding 10 20'
>>> 
>>> someInput = sys.stdin.read()
Ding 10 20
D
>>> 
>>> someInput
'Ding 10 20\nD\n'

#__________________________________________________________________

>>> sys.path
['', '/usr/lib/python38.zip', '/usr/lib/python3.8', '/usr/lib/python3.8/lib-dynload', '/home/khoj/.local/lib/python3.8/site-packages', '/usr/local/lib/python3.8/dist-packages', '/usr/lib/python3/dist-packages']
>>> 
>>> 
>>> import os
>>> 
>>> os.getcwd()
'/home/khoj/Documents/AltioStar/Progress'
>>> 
>>> 
>>> os.listdir()
['countWordsBetter.py', 'wordsList1.txt', 'Discussions.py', 'PythonExperiments3.py', 'PythonExperiments1.py', 'Functions.py', 'countWords.py', 'wordsList.txt', 'PythonExperiments2.py', 'ReadFiles.py', 'Hello.py', 'SystemArgs.py']
>>> 
>>> 
>>> 
>>> files = os.listdir()
>>> 
>>> for file in files:
...     print(file)
... 
countWordsBetter.py
wordsList1.txt
Discussions.py
PythonExperiments3.py
PythonExperiments1.py
Functions.py
countWords.py
wordsList.txt
PythonExperiments2.py
ReadFiles.py
Hello.py
SystemArgs.py
>>> 
>>> dir(os_
... 
KeyboardInterrupt
>>> dir(os)
['CLD_CONTINUED', 'CLD_DUMPED', 'CLD_EXITED', 'CLD_TRAPPED', 'DirEntry', 'EX_CANTCREAT', 'EX_CONFIG', 'EX_DATAERR', 'EX_IOERR', 'EX_NOHOST', 'EX_NOINPUT', 'EX_NOPERM', 'EX_NOUSER', 'EX_OK', 'EX_OSERR', 'EX_OSFILE', 'EX_PROTOCOL', 'EX_SOFTWARE', 'EX_TEMPFAIL', 'EX_UNAVAILABLE', 'EX_USAGE', 'F_LOCK', 'F_OK', 'F_TEST', 'F_TLOCK', 'F_ULOCK', 'GRND_NONBLOCK', 'GRND_RANDOM', 'MFD_ALLOW_SEALING', 'MFD_CLOEXEC', 'MFD_HUGETLB', 'MFD_HUGE_16GB', 'MFD_HUGE_16MB', 'MFD_HUGE_1GB', 'MFD_HUGE_1MB', 'MFD_HUGE_256MB', 'MFD_HUGE_2GB', 'MFD_HUGE_2MB', 'MFD_HUGE_32MB', 'MFD_HUGE_512KB', 'MFD_HUGE_512MB', 'MFD_HUGE_64KB', 'MFD_HUGE_8MB', 'MFD_HUGE_MASK', 'MFD_HUGE_SHIFT', 'MutableMapping', 'NGROUPS_MAX', 'O_ACCMODE', 'O_APPEND', 'O_ASYNC', 'O_CLOEXEC', 'O_CREAT', 'O_DIRECT', 'O_DIRECTORY', 'O_DSYNC', 'O_EXCL', 'O_LARGEFILE', 'O_NDELAY', 'O_NOATIME', 'O_NOCTTY', 'O_NOFOLLOW', 'O_NONBLOCK', 'O_PATH', 'O_RDONLY', 'O_RDWR', 'O_RSYNC', 'O_SYNC', 'O_TMPFILE', 'O_TRUNC', 'O_WRONLY', 'POSIX_FADV_DONTNEED', 'POSIX_FADV_NOREUSE', 'POSIX_FADV_NORMAL', 'POSIX_FADV_RANDOM', 'POSIX_FADV_SEQUENTIAL', 'POSIX_FADV_WILLNEED', 'POSIX_SPAWN_CLOSE', 'POSIX_SPAWN_DUP2', 'POSIX_SPAWN_OPEN', 'PRIO_PGRP', 'PRIO_PROCESS', 'PRIO_USER', 'P_ALL', 'P_NOWAIT', 'P_NOWAITO', 'P_PGID', 'P_PID', 'P_WAIT', 'PathLike', 'RTLD_DEEPBIND', 'RTLD_GLOBAL', 'RTLD_LAZY', 'RTLD_LOCAL', 'RTLD_NODELETE', 'RTLD_NOLOAD', 'RTLD_NOW', 'RWF_DSYNC', 'RWF_HIPRI', 'RWF_NOWAIT', 'RWF_SYNC', 'R_OK', 'SCHED_BATCH', 'SCHED_FIFO', 'SCHED_IDLE', 'SCHED_OTHER', 'SCHED_RESET_ON_FORK', 'SCHED_RR', 'SEEK_CUR', 'SEEK_DATA', 'SEEK_END', 'SEEK_HOLE', 'SEEK_SET', 'ST_APPEND', 'ST_MANDLOCK', 'ST_NOATIME', 'ST_NODEV', 'ST_NODIRATIME', 'ST_NOEXEC', 'ST_NOSUID', 'ST_RDONLY', 'ST_RELATIME', 'ST_SYNCHRONOUS', 'ST_WRITE', 'TMP_MAX', 'WCONTINUED', 'WCOREDUMP', 'WEXITED', 'WEXITSTATUS', 'WIFCONTINUED', 'WIFEXITED', 'WIFSIGNALED', 'WIFSTOPPED', 'WNOHANG', 'WNOWAIT', 'WSTOPPED', 'WSTOPSIG', 'WTERMSIG', 'WUNTRACED', 'W_OK', 'XATTR_CREATE', 'XATTR_REPLACE', 'XATTR_SIZE_MAX', 'X_OK', '_Environ', '__all__', '__builtins__', '__cached__', '__doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__', '_check_methods', '_execvpe', '_exists', '_exit', '_fspath', '_fwalk', '_get_exports_list', '_putenv', '_spawnvef', '_unsetenv', '_wrap_close', 'abc', 'abort', 'access', 'altsep', 'chdir', 'chmod', 'chown', 'chroot', 'close', 'closerange', 'confstr', 'confstr_names', 'copy_file_range', 'cpu_count', 'ctermid', 'curdir', 'defpath', 'device_encoding', 'devnull', 'dup', 'dup2', 'environ', 'environb', 'error', 'execl', 'execle', 'execlp', 'execlpe', 'execv', 'execve', 'execvp', 'execvpe', 'extsep', 'fchdir', 'fchmod', 'fchown', 'fdatasync', 'fdopen', 'fork', 'forkpty', 'fpathconf', 'fsdecode', 'fsencode', 'fspath', 'fstat', 'fstatvfs', 'fsync', 'ftruncate', 'fwalk', 'get_blocking', 'get_exec_path', 'get_inheritable', 'get_terminal_size', 'getcwd', 'getcwdb', 'getegid', 'getenv', 'getenvb', 'geteuid', 'getgid', 'getgrouplist', 'getgroups', 'getloadavg', 'getlogin', 'getpgid', 'getpgrp', 'getpid', 'getppid', 'getpriority', 'getrandom', 'getresgid', 'getresuid', 'getsid', 'getuid', 'getxattr', 'initgroups', 'isatty', 'kill', 'killpg', 'lchown', 'linesep', 'link', 'listdir', 'listxattr', 'lockf', 'lseek', 'lstat', 'major', 'makedev', 'makedirs', 'memfd_create', 'minor', 'mkdir', 'mkfifo', 'mknod', 'name', 'nice', 'open', 'openpty', 'pardir', 'path', 'pathconf', 'pathconf_names', 'pathsep', 'pipe', 'pipe2', 'popen', 'posix_fadvise', 'posix_fallocate', 'posix_spawn', 'posix_spawnp', 'pread', 'preadv', 'putenv', 'pwrite', 'pwritev', 'read', 'readlink', 'readv', 'register_at_fork', 'remove', 'removedirs', 'removexattr', 'rename', 'renames', 'replace', 'rmdir', 'scandir', 'sched_get_priority_max', 'sched_get_priority_min', 'sched_getaffinity', 'sched_getparam', 'sched_getscheduler', 'sched_param', 'sched_rr_get_interval', 'sched_setaffinity', 'sched_setparam', 'sched_setscheduler', 'sched_yield', 'sendfile', 'sep', 'set_blocking', 'set_inheritable', 'setegid', 'seteuid', 'setgid', 'setgroups', 'setpgid', 'setpgrp', 'setpriority', 'setregid', 'setresgid', 'setresuid', 'setreuid', 'setsid', 'setuid', 'setxattr', 'spawnl', 'spawnle', 'spawnlp', 'spawnlpe', 'spawnv', 'spawnve', 'spawnvp', 'spawnvpe', 'st', 'stat', 'stat_result', 'statvfs', 'statvfs_result', 'strerror', 'supports_bytes_environ', 'supports_dir_fd', 'supports_effective_ids', 'supports_fd', 'supports_follow_symlinks', 'symlink', 'sync', 'sys', 'sysconf', 'sysconf_names', 'system', 'tcgetpgrp', 'tcsetpgrp', 'terminal_size', 'times', 'times_result', 'truncate', 'ttyname', 'umask', 'uname', 'uname_result', 'unlink', 'unsetenv', 'urandom', 'utime', 'wait', 'wait3', 'wait4', 'waitid', 'waitid_result', 'waitpid', 'walk', 'write', 'writev']
>>> 
>>> os.mkdir("Training")
>>> os.mkdir("StudyWell")
>>> 
>>> os.listdir()
['countWordsBetter.py', 'wordsList1.txt', 'Discussions.py', 'PythonExperiments3.py', 'PythonExperiments1.py', 'Functions.py', 'Training', 'countWords.py', 'wordsList.txt', 'PythonExperiments2.py', 'StudyWell', 'ReadFiles.py', 'Hello.py', 'SystemArgs.py']
>>> 
>>> os.rmdir("Training")
>>> 
>>> os.listdir()
['countWordsBetter.py', 'wordsList1.txt', 'Discussions.py', 'PythonExperiments3.py', 'PythonExperiments1.py', 'Functions.py', 'countWords.py', 'wordsList.txt', 'PythonExperiments2.py', 'StudyWell', 'ReadFiles.py', 'Hello.py', 'SystemArgs.py']


#__________________________________________________________________

Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> 
>>> 
>>> textFile = open("textFile.txt", "w")
>>> data = 80
>>> 
>>> textFile.write(data)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: write() argument must be str, not int
>>> 
>>> textFile.write(str(data))
8
>>> textFile.close()
>>> 
>>> 
>>> binaryFile = open("binaryFile.txt", "wb")
>>> 
>>> binaryFile.write(data)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: a bytes-like object is required, not 'int'
>>> 
>>> binaryFile.write( bytes(data) )
80807060
>>> 
>>> binaryFile.close()

#__________________________________________________________________


>>> import pathlib
>>> 
>>> dir(pathlib)
['EBADF', 'EINVAL', 'ELOOP', 'ENOENT', 'ENOTDIR', 'Path', 'PosixPath', 'PurePath', 'PurePosixPath', 'PureWindowsPath', 'S_ISBLK', 'S_ISCHR', 'S_ISDIR', 'S_ISFIFO', 'S_ISLNK', 'S_ISREG', 'S_ISSOCK', 'Sequence', 'WindowsPath', '_Accessor', '_Flavour', '_IGNORED_ERROS', '_IGNORED_WINERRORS', '_NormalAccessor', '_PathParents', '_PosixFlavour', '_PreciseSelector', '_RecursiveWildcardSelector', '_Selector', '_TerminatingSelector', '_WildcardSelector', '_WindowsFlavour', '__all__', '__builtins__', '__cached__', '__doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__', '_ignore_error', '_is_wildcard_pattern', '_make_selector', '_normal_accessor', '_posix_flavour', '_windows_flavour', 'attrgetter', 'fnmatch', 'functools', 'io', 'nt', 'ntpath', 'os', 'posixpath', 're', 'supports_symlinks', 'sys', 'urlquote_from_bytes']
>>> 
>>> 
>>> pathlib.os
<module 'os' from '/usr/lib/python3.8/os.py'>
>>> 
>>> 
>>> 
>>> testFile = pathlib.Path("newTextFile.txt")
>>> 
>>> testFile.write_text("Hello World, How Are You Doing?")
31
>>> testFile.read_text()
'Hello World, How Are You Doing?'
>>> 
>>> 
>>> binaryFile = pathLib.Path("newBinaryFile.txt")
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'pathLib' is not defined
>>> 
>>> 
>>> binaryFile = pathlib.Path("newBinaryFile.txt")
>>> 
>>> binaryFile.write_bytes( b"Hello World, How Are You Doing?" )
31
>>> binaryFile.read_bytes()
b'Hello World, How Are You Doing?'


#__________________________________________________________________

>>> data = input("Enter Number: ")
Enter Number: 90
>>> 
>>> data
'90'
>>> type(data)
<class 'str'>
>>> 
>>> number = int(data)
>>> 
>>> number
90
>>> type(number)
<class 'int'>
>>> 
>>> data = input("Enter Decimal Number: ")
Enter Decimal Number: 90.78
>>> 
>>> data
'90.78'
>>> t
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 't' is not defined
>>> type(data)
<class 'str'>
>>> 
>>> ff = float(data)
>>> 
>>> ff
90.78
>>> 

#__________________________________________________________________

>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'binaryFile', 'data', 'ff', 'number', 'pathlib', 'testFile', 'textFile']
>>> 
>>> del ff
>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'binaryFile', 'data', 'number', 'pathlib', 'testFile', 'textFile']
>>> 
>>> del number
>>> ff
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'ff' is not defined
>>> dir
<built-in function dir>
>>> 
>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'binaryFile', 'data', 'pathlib', 'testFile', 'textFile']
>>> quit()
khoj@Universe:~/Documents/AltioStar/Progress$ 
khoj@Universe:~/Documents/AltioStar/Progress$ 
khoj@Universe:~/Documents/AltioStar/Progress$ 
khoj@Universe:~/Documents/AltioStar/Progress$ python3
Python 3.8.10 (default, Sep 28 2021, 16:10:42) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> 
>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__']
>>> 
>>> __name__
'__main__'
>>> 
>>> type(__name__)
<class 'str'>
>>> 
>>> 
>>> dir(__builtins__)
['ArithmeticError', 'AssertionError', 'AttributeError', 'BaseException', 'BlockingIOError', 'BrokenPipeError', 'BufferError', 'BytesWarning', 'ChildProcessError', 'ConnectionAbortedError', 'ConnectionError', 'ConnectionRefusedError', 'ConnectionResetError', 'DeprecationWarning', 'EOFError', 'Ellipsis', 'EnvironmentError', 'Exception', 'False', 'FileExistsError', 'FileNotFoundError', 'FloatingPointError', 'FutureWarning', 'GeneratorExit', 'IOError', 'ImportError', 'ImportWarning', 'IndentationError', 'IndexError', 'InterruptedError', 'IsADirectoryError', 'KeyError', 'KeyboardInterrupt', 'LookupError', 'MemoryError', 'ModuleNotFoundError', 'NameError', 'None', 'NotADirectoryError', 'NotImplemented', 'NotImplementedError', 'OSError', 'OverflowError', 'PendingDeprecationWarning', 'PermissionError', 'ProcessLookupError', 'RecursionError', 'ReferenceError', 'ResourceWarning', 'RuntimeError', 'RuntimeWarning', 'StopAsyncIteration', 'StopIteration', 'SyntaxError', 'SyntaxWarning', 'SystemError', 'SystemExit', 'TabError', 'TimeoutError', 'True', 'TypeError', 'UnboundLocalError', 'UnicodeDecodeError', 'UnicodeEncodeError', 'UnicodeError', 'UnicodeTranslateError', 'UnicodeWarning', 'UserWarning', 'ValueError', 'Warning', 'ZeroDivisionError', '_', '__build_class__', '__debug__', '__doc__', '__import__', '__loader__', '__name__', '__package__', '__spec__', 'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'breakpoint', 'bytearray', 'bytes', 'callable', 'chr', 'classmethod', 'compile', 'complex', 'copyright', 'credits', 'delattr', 'dict', 'dir', 'divmod', 'enumerate', 'eval', 'exec', 'exit', 'filter', 'float', 'format', 'frozenset', 'getattr', 'globals', 'hasattr', 'hash', 'help', 'hex', 'id', 'input', 'int', 'isinstance', 'issubclass', 'iter', 'len', 'license', 'list', 'locals', 'map', 'max', 'memoryview', 'min', 'next', 'object', 'oct', 'open', 'ord', 'pow', 'print', 'property', 'quit', 'range', 'repr', 'reversed', 'round', 'set', 'setattr', 'slice', 'sorted', 'staticmethod', 'str', 'sum', 'super', 'tuple', 'type', 'vars', 'zip']
>>> 
>>> 
>>> type(__builtins__)
<class 'module'>
>>> 
>>> 
>>> a = 7
>>> _
<class 'module'>
>>> 
>>> a + b
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'b' is not defined
>>> 
>>> a + 10
17
>>> _
17
>>> 
>>> 
>>> int = 90
>>> 
>>> int
90
>>> a = int()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'int' object is not callable
>>> 
>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'a', 'int']
>>> del int
>>> del a
>>> 
>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__']
>>> 
>>> 
>>> def sum(a, b):
...     return a + b
... 
>>> sum(10, 20)
30
>>> 
>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'sum']
>>> 
>>> 
>>> number = 90.901
>>> dir()
['__annotations__', '__builtins__', '__doc__', '__loader__', '__name__', '__package__', '__spec__', 'number', 'sum']
>>> 

#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________


#__________________________________________________________________

#__________________________________________________________________

#__________________________________________________________________

#__________________________________________________________________

#__________________________________________________________________

#__________________________________________________________________

#__________________________________________________________________

#__________________________________________________________________

#__________________________________________________________________

